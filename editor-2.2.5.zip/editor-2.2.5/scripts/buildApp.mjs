import { build } from 'vite'

build()
