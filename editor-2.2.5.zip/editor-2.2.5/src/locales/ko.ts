import { ko } from 'vuetify/src/locale'

export default {
	...ko,
	languageName: '한국어',
	// Toolbar Categories
	toolbar: {
		installApp: 'Install app',
		file: {
			name: '파일',
			newFile: '새로운 파일',
			import: {
				name: '파일 가져오기',
				openFile: '파일 열기',
				importOBJ: 'OBJ 모델 가져오기',
			},
			saveFile: '파일 저장',
			saveAs: '다른 이름으로 저장',
			saveAll: '모두 저장',
			closeEditor: '편집 창 닫기',
			clearAllNotifications: '알림 전부 지우기',
			preferences: {
				name: '환경 설정',
				settings: '설정',
				extensions: '플러그인',
			},
		},
		edit: {
			name: '편집',
			selection: {
				name: '선택',
				unselect: '선택 취소',
				selectParent: '어버이 선택',
				selectNext: '다음 선택',
				selectPrevious: '이전 선택',
			},
			jsonNodes: {
				name: 'JSON 개체',
				toggleOpen: '개체 여닫기',
				toggleOpenChildren: '개체 자식 여닫기',
				moveDown: '아래로 이동',
				moveUp: '위로 이동',
				commentUncomment: '활성화/비활성화',
			},
			delete: '삭제',
			undo: '실행 취소',
			redo: '재실행',
			copy: '복사',
			cut: '자르기',
			paste: '붙여넣기',
			alternativePaste: '다른 붙여넣기',
		},
		tools: {
			name: '도구',
			docs: '정보 기록문',
			presets: '프리셋',
			snippets: '부분적 인용',
			goToFile: '파일로 이동',
		},
		help: {
			name: '도움말',
			about: '정보',
			releases: '최신 릴리스',
			bugReports: '버그 제보',
			pluginAPI: '플러그인 API',
			gettingStarted: 'bridge. 시작하는 법',
			faq: 'FAQ',
		},
		dev: {
			name: '개발자 옵션',
			reloadBrowserWindow: '브라우저 창 재실행',
			reloadEditorData: '편집 데이터 재실행',
			developerTools: '개발자 도구',
		},
	},
	// Sidebar tabs
	sidebar: {
		explorer: {
			name: '익스플로러',
		},
		vanillaPacks: {
			name: '바닐라 팩',
		},
		debugLog: {
			name: '디버그 로그',
		},
		extensions: {
			name: '프로그램 확장',
			intro: {
				description:
					'bridge.를 플러그인을 통해 커스터마이즈 해보세요!!',
				themes: '테마',
				snippets: '부분적 인용',
				presets: '프리셋',
				uiElements: 'UI 요소',
				andMore: '그리고 더 많습니다!!',
				viewExtensions: '프로그램 확장들 보기',
			},
		},
	},
	// Welcome Screen
	welcome: {
		title: 'bridge.',
		subtitle: '마인크래프트 애드온을 만들기 더욱 쉽게!!',
		syntaxHighlighting: 'Syntax 하이라이트 기능',
		richAutoCompletions: '다양한 자동완성 기능',
		projectManagement: '쉬운 작업 관리',
		customSyntax: '커스텀 애드온 syntax',
		customComponents: '커스텀 요소',
		customCommands: '커스텀 커맨드',
		plugins: '플러그인을 통해 프로그램 커스텀 가능',
	},
	// Windows
	windows: {
		common: {
			confirm: {
				title: '확인',
			},
			dropdown: {
				confirm: '확인',
			},
			information: {
				confirm: '예',
			},
			input: {
				confirm: '확인',
			},
		},
		discord: {
			content: 'bridge.의 공식 디스코드 서버에 들어오세요!!',
			join: '들어가기',
			later: '나중에',
		},
		selectFolder: {
			title: '폴더 선택',
			content:
				'프로젝트 저장 위치를 선택하거나 이미 존재하는 디렉토리를 선택하세요.',
			select: '선택!!',
		},
		projectFolder: {
			title: '프로젝트 폴더',
			content:
				'bridge.가 제대로 작동하기 위해서는 프로젝트 폴더에 대한 접근 권한이 필요합니다.',
		},
		managePlugin: {
			name: '플러그인 관리',
			done: '완료',
		},
	},
}
