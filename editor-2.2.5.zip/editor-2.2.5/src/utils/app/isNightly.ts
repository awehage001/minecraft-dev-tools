export const isNightly = location.origin === 'https://nightly.bridge-core.app'
