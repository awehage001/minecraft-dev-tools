export { version } from '../../../package.json'
