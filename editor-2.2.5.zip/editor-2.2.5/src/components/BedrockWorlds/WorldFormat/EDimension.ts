export enum EDimension {
	Overworld = 0,
	Nether = 1,
	TheEnd = 2,
}
