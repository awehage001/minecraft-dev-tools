export interface IMkdirConfig {
	recursive: boolean
}

export interface IGetHandleConfig {
	create: boolean
	createOnce: boolean
}
