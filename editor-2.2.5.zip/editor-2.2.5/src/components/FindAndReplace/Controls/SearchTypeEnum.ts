export enum ESearchType {
	matchCase = 0,
	ignoreCase,
	useRegExp,
}
