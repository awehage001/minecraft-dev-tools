export class SmartWarning {
	constructor(
		public value: string | string[],
		public start: number,
		public end: number
	) {}
}
