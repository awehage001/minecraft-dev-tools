import { Model, StandaloneModelViewer } from 'bridge-model-viewer'

export const ModelViewerModule = () => ({
	Model,
	StandaloneModelViewer,
})
