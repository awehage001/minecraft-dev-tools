import { compareVersions } from 'bridge-common-utils'

export const CompareVersions = () => ({
	compare: compareVersions,
})
