export const SettingsModule = () => ({})
