import * as path from '/@/utils/path'

export const PathModule = () => path
