export const ThreeModule = () => import('three')
