export interface IDisposable {
	dispose: () => void
}
