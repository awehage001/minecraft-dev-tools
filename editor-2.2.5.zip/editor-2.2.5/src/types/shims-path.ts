declare module 'path-browserify' {
	import path from 'path'
	export default path
}
